/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package st10261874_question2;

import static org.hamcrest.CoreMatchers.is;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Dianca
 */
public class OrderTest {
    
  @Test
    public void testOrders() {
        Customer customer = new Customer("John");
        Order order = new Order(customer);

        assertThat(order.getOrderNumber(), is(2));
        assertThat(order.getCustomer(), is(customer));
        assertNull(order.getSushiItem());
        assertNull(order.getDrinkItem());
    }

    @Test
    public void testSetSushiItem() {
        Customer customer = new Customer("John");
        Order order = new Order(customer);

        Menu sushiItem = new Menu("Salmon Nigiri", 50.00);
        order.setSushiItem(sushiItem);

        assertThat(order.getSushiItem(), is(sushiItem));
    }

    @Test
    public void testSetDrinkItem() {
        Customer customer = new Customer("John");
        Order order = new Order(customer);

        Menu drinkItem = new Menu("Coke", 30.00);
        order.setDrinkItem(drinkItem);

        assertThat(order.getDrinkItem(), is(drinkItem));
    }

    @Test
    public void testCalculateTotalCost() {
        Customer customer = new Customer("John");
        Order order = new Order(customer);

        Menu sushiItem = new Menu("Salmon Nigiri", 50.00);
        Menu drinkItem = new Menu("Coke", 30.00);

        order.setSushiItem(sushiItem);
        order.setDrinkItem(drinkItem);

        assertThat(order.calculateTotalCost(), is(80.00));
    }

       @Test
    public void testDisplay() {
        Customer customer = new Customer("John");
        Order order = new Order(customer);

        Menu sushiItem = new Menu("Salmon Nigiri", 50.00);
        Menu drinkItem = new Menu("Coke", 30.00);

        order.setSushiItem(sushiItem);
        order.setDrinkItem(drinkItem);

        String expectedOutput = "Order Number: 1\n" +
                "Customer: John\n" +
                "Sushi Item: Salmon Nigiri (R50.0)\n" +
                "Drink Item: Coke (R30.0)\n" +
                "Total Cost: R80.0\n" +
                "-----------------------";

        assertThat(order.toString(), is(expectedOutput));
    }
}