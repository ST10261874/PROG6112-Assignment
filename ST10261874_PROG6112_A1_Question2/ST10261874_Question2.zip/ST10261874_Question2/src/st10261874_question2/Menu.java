/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package st10261874_question2;

/**
 *
 * @author Dianca
 */
public class Menu {
  private String name;
    private double price;

    public Menu(String name, double price) {
        this.name = name;
        this.price = price;
    }

    //getter methods to access name and price
    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    //Override toString to display info
    @Override
    public String toString() {
        return name + " (R" + price + ")";
    }
}