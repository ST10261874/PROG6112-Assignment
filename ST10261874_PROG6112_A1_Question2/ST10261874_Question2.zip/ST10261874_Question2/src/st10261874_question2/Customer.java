/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package st10261874_question2;

/**
 *
 * @author Dianca
 */

public class Customer {
  private String name;

    public Customer(String name) {
        this.name = name;
    }

    //getter method to access customer name
    public String getName() {
        return name;
    }
    
}