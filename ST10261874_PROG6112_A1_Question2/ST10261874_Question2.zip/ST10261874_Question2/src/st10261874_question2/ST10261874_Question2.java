/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package st10261874_question2;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import javax.swing.JOptionPane;

/*
REFERENCES:
https://www.baeldung.com/java-generics
https://docs.oracle.com/javase/tutorial/java/generics/methods.html#:~:text=The%20syntax%20for%20a%20generic,before%20the%20method's%20return%20type.
https://www.geeksforgeeks.org/hashset-in-java/
https://www.javatpoint.com/java-hashset
*/
public class ST10261874_Question2 {

    public static void main(String[] args) {
        
        //initialising lists and sets
       ArrayList<Order> orders = new ArrayList<>();
        Set<String> sushiOrdered = new HashSet<>();
        Set<String> drinkOrdered = new HashSet<>();

        //creating all sushi options
        Sushi[] sushiOptions = {
            new Sushi("Salmon Nigiri", 50.00),
            new Sushi("Tuna Roll", 45.00),
            new Sushi("California Roll", 30.00),
            new Sushi("Tempura Roll", 60.00),
            new Sushi("Salmon Sashimi", 50.00)
        };

        //creating drink options    
        Drinks[] drinkOptions = {
            new Drinks("Coke", 30.00),
            new Drinks("Fanta", 20.00),
            new Drinks("Wine", 200.00),
            new Drinks("Green Tea", 25.00),
            new Drinks("Gin", 250.00)
        };

        boolean continueOrdering = true;

        while (continueOrdering) {
         //get customer name and create a new order   
            String customerName = JOptionPane.showInputDialog(null, "Enter your name:", "Customer Name", JOptionPane.PLAIN_MESSAGE);

            Customer customer = new Customer(customerName);
            Order order = new Order(customer);

            // Reset ordered items for the new customer
            sushiOrdered.clear();
            drinkOrdered.clear();

            // Sushi selection
            Menu sushiItem = offerItems(sushiOptions, "Select a sushi item:", "Sushi Selection");
            if (sushiItem != null) {
                sushiOrdered.add(sushiItem.getName());
                order.setSushiItem(sushiItem);
            }

            // Drink selection
            Menu drinkItem = offerItems(drinkOptions, "Select a drink item:", "Drink Selection");
            if (drinkItem != null) {
                drinkOrdered.add(drinkItem.getName());
                order.setDrinkItem(drinkItem);
            }
               //orders will be added to the list of orders 
            orders.add(order);
            
            //to place another person's order
            int response = JOptionPane.showConfirmDialog(null, "Do you want to take another order?", "Continue Ordering", JOptionPane.YES_NO_OPTION);
            if (response != JOptionPane.YES_OPTION) {
                continueOrdering = false;
            }
        }
        
        //display all order details
        StringBuilder allOrdersDetails = new StringBuilder("ORDER DETAILS:\n\n");
        for (Order order : orders) {
            allOrdersDetails.append(order).append("\n");
        }
        JOptionPane.showMessageDialog(null, allOrdersDetails.toString());
    }

    //offer a selection of menu items to the user.
    //generic method used 
    private static <T extends Menu> T offerItems(T[] items, String message, String title) {
        String[] itemChoiceOptions = new String[items.length];
        for (int i = 0; i < items.length; i++) {
            itemChoiceOptions[i] = items[i].toString();
        }
        String itemChoice = (String) JOptionPane.showInputDialog(null, message, title, JOptionPane.QUESTION_MESSAGE, null, itemChoiceOptions, itemChoiceOptions[0]);
        if (itemChoice == null) {
            return null; 
        }
        for (T item : items) {
            if (itemChoice.equals(item.toString())) {
                return item;
            }
        }
        return null; 
    }
}