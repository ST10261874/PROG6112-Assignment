/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package st10261874_question2;

import java.util.ArrayList;

/**
 *
 * @author Dianca
 */
public class Order {
 private static int nextOrderNumber = 1;
    private int orderNumber;
    private Customer customer;
    private Menu sushiItem;
    private Menu drinkItem;

    public Order(Customer customer) {
        this.orderNumber = nextOrderNumber++;
        this.customer = customer;
    }

    //setter methods for sushi and drinks
    public void setSushiItem(Menu sushiItem) {
        this.sushiItem = sushiItem;
    }

    public void setDrinkItem(Menu drinkItem) {
        this.drinkItem = drinkItem;
    }

    //the getter methods access the order details
    public int getOrderNumber() {
        return orderNumber;
    }

    public Customer getCustomer() {
        return customer;
    }

    public Menu getSushiItem() {
        return sushiItem;
    }

    public Menu getDrinkItem() {
        return drinkItem;
    }

    //calculating total cost of order
    public double calculateTotalCost() {
        double totalCost = 0;
        
        //nested if statement used
        if (sushiItem != null) {
            totalCost += sushiItem.getPrice();
        }
        if (drinkItem != null) {
            totalCost += drinkItem.getPrice();
        }
        return totalCost;
    }

    //display order details
    @Override
    public String toString() {
        StringBuilder details = new StringBuilder();
        details.append("Order Number: ").append(orderNumber).append("\n");
        details.append("Customer: ").append(customer.getName()).append("\n");
        if (sushiItem != null) {
            details.append("Sushi Item: ").append(sushiItem).append("\n");
        }
        if (drinkItem != null) {
            details.append("Drink Item: ").append(drinkItem).append("\n");
        }
        details.append("Total Cost: R").append(calculateTotalCost()).append("\n");
        details.append("-----------------------");
        return details.toString();
    }
}