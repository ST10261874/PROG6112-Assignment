/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package st10261874_question2;

/**
 *
 * @author Dianca
 */

//subclass of Menu
public class Drinks extends Menu{
    public Drinks(String name, double price) {
        super(name, price);
    }
}
